function s_des = trajectory_generator(t, path, h)
% -------------------------------------------------------------------
% Minimum-snap trajectory generator (7th-order piecewise polynomials)
% - Init pass (nargin>1): pre-compute coefficients for all segments
% - Query pass (nargin==1): return desired state at time t
% -------------------------------------------------------------------
persistent waypoints num traj_time time_interval pos_coeffs vel_coeffs

s_des = zeros(13,1);
s_des(7:10) = [1;0;0;0];   % desired orientation: identity quat

% ===================== Part I: Initialization ======================
if nargin > 1
    waypoints = path;
    num = size(waypoints,1) - 1;                 % number of segments
    if num < 1, error('Need at least 2 waypoints.'); end

    % ---- time allocation (unit speed) ----
    time_interval = zeros(num,1);
    for i = 1:num
        d = norm(waypoints(i+1,:) - waypoints(i,:));
        time_interval(i) = max(d, 1e-3);         % avoid zero time
    end
    traj_time = [0; cumsum(time_interval)];      % [0, T1, T1+T2, ..., Tend]

    % ---- build Q (∫ snap^2) and M (coeff -> boundary derivatives) ----
    Q = zeros(8*num, 8*num);
    M = zeros(8*num, 8*num);
    for i = 1:num
        T = time_interval(i);
        Qi = zeros(8,8);
        % Only a4..a7 contribute to 4th derivative
        for k = 4:7
            for l = 4:7
                ckl = fact_ratio(k,4) * fact_ratio(l,4) * T^(k+l-7)/(k+l-7);
                Qi(k+1,l+1) = ckl;
            end
        end
        idx = (i-1)*8 + (1:8);
        Q(idx,idx) = Qi;

        Mi = zeros(8,8);
        % rows 1..4: at t=0, derivatives 0..3
        for r = 0:3
            Mi(r+1,:) = dpoly_row(7, r, 0);
        end
        % rows 5..8: at t=T, derivatives 0..3
        for r = 0:3
            Mi(4+r+1,:) = dpoly_row(7, r, T);
        end
        M(idx,idx) = Mi;
    end

    % ---- build selection matrix C (maps unique boundary vars d -> stacked D) ----
    % d = [positions on each segment boundary (2N);
    %      boundary v/a/j at start & end (6);
    %      interior waypoint v/a/j for k=2..N (3*(N-1))]   total = 5N+3
    nF = 2*num + 6;             % fixed part length (2N positions + 6 boundary derivatives)
    nP = 3*(num - 1);           % free interior derivatives (v/a/j at waypoints 2..N)
    d_cols = nF + nP;           % = 5N + 3
    C = zeros(8*num, d_cols);

    % column bookkeeping
    pos_s_idx = zeros(num,1);   % position at start of segment i
    pos_e_idx = zeros(num,1);   % position at end   of segment i
    col = 0;
    for i = 1:num
        col = col + 1; pos_s_idx(i) = col;
        col = col + 1; pos_e_idx(i) = col;
    end
    % boundary derivatives at the very start and end
    col_v0 = col+1; col_a0 = col+2; col_j0 = col+3;
    col_vT = col+4; col_aT = col+5; col_jT = col+6;
    col = col + 6;

    % interior derivatives (waypoints 2..N)
    v_int = zeros(num+1,1); a_int = zeros(num+1,1); j_int = zeros(num+1,1);
    for k = 2:num
        v_int(k) = col + 1; a_int(k) = col + 2; j_int(k) = col + 3;
        col = col + 3;
    end
    if col ~= d_cols
        error('C column count mismatch.');
    end

    % fill C rows for each segment
    for i = 1:num
        r0 = (i-1)*8;                % row offset

        % start of segment i corresponds to waypoint i
        C(r0+1, pos_s_idx(i)) = 1;                    % position
        if i == 1
            C(r0+2, col_v0) = 1; C(r0+3, col_a0) = 1; C(r0+4, col_j0) = 1;
        else
            C(r0+2, v_int(i)) = 1; C(r0+3, a_int(i)) = 1; C(r0+4, j_int(i)) = 1;
        end

        % end of segment i corresponds to waypoint i+1
        C(r0+5, pos_e_idx(i)) = 1;                    % position
        if i == num
            C(r0+6, col_vT) = 1; C(r0+7, col_aT) = 1; C(r0+8, col_jT) = 1;
        else
            C(r0+6, v_int(i+1)) = 1; C(r0+7, a_int(i+1)) = 1; C(r0+8, j_int(i+1)) = 1;
        end
    end

    % ---- assemble R and closed-form solve for d_P ----
    Minv = inv(M);
    R = C' * (Minv') * Q * Minv * C;

    R_FF = R(1:nF, 1:nF);
    R_FP = R(1:nF, nF+1:end);
    R_PF = R(nF+1:end, 1:nF);
    R_PP = R(nF+1:end, nF+1:end);

    % fixed vector d_F (per axis填值；P由最优性求得)
    d_Fx = zeros(nF,1); d_Fy = zeros(nF,1); d_Fz = zeros(nF,1);

    % 2N fixed positions (start_i, end_i) for each segment
    for i = 1:num
        d_Fx(pos_s_idx(i)) = waypoints(i,1);
        d_Fx(pos_e_idx(i)) = waypoints(i+1,1);
        d_Fy(pos_s_idx(i)) = waypoints(i,2);
        d_Fy(pos_e_idx(i)) = waypoints(i+1,2);
        d_Fz(pos_s_idx(i)) = waypoints(i,3);
        d_Fz(pos_e_idx(i)) = waypoints(i+1,3);
    end

    % boundary derivatives at t0 and tEnd: set to zero
    % (v0,a0,j0,vT,aT,jT)
    % already zeros

    % solve for interior derivatives (free part)
    d_Px = -(R_PP \ (R_PF * d_Fx));
    d_Py = -(R_PP \ (R_PF * d_Fy));
    d_Pz = -(R_PP \ (R_PF * d_Fz));

    d_x = [d_Fx; d_Px];
    d_y = [d_Fy; d_Py];
    d_z = [d_Fz; d_Pz];

    % ---- back to polynomial coefficients: p = M^{-1} C d ----
    p_x_vec = Minv * C * d_x;    % length 8*num, stacked by segments
    p_y_vec = Minv * C * d_y;
    p_z_vec = Minv * C * d_z;

    p_x = reshape(p_x_vec, 8, num)';   % num x 8, [a0..a7]
    p_y = reshape(p_y_vec, 8, num)';
    p_z = reshape(p_z_vec, 8, num)';

    pos_coeffs = [p_x, p_y, p_z];      % num x 24 (每轴8列)

    % velocity coefficients (一阶导)
    vx = [p_x(:,2), 2*p_x(:,3), 3*p_x(:,4), 4*p_x(:,5), 5*p_x(:,6), 6*p_x(:,7), 7*p_x(:,8), zeros(num,1)];
    vy = [p_y(:,2), 2*p_y(:,3), 3*p_y(:,4), 4*p_y(:,5), 5*p_y(:,6), 6*p_y(:,7), 7*p_y(:,8), zeros(num,1)];
    vz = [p_z(:,2), 2*p_z(:,3), 3*p_z(:,4), 4*p_z(:,5), 5*p_z(:,6), 6*p_z(:,7), 7*p_z(:,8), zeros(num,1)];
    vel_coeffs = [vx, vy, vz];

    % ---- visualization of the planned path ----
    if ~isempty(h)
        subplot(h); hold on;
        pos_x = []; pos_y = []; pos_z = [];
        for i = 1:num
            T = time_interval(i);
            tt = 0:0.01:T;
            pos_xi = polyval(flip(p_x(i,:)), tt);
            pos_yi = polyval(flip(p_y(i,:)), tt);
            pos_zi = polyval(flip(p_z(i,:)), tt);
            pos_x = [pos_x pos_xi]; %#ok<AGROW>
            pos_y = [pos_y pos_yi];
            pos_z = [pos_z pos_zi];
        end
        plot3(pos_x, pos_y, pos_z, 'r-', 'LineWidth', 2);
        hold off;
    end

% ===================== Part II: Query ======================
else
    % clamp to final time
    if t > traj_time(end), t = traj_time(end); end
    t_index = find(traj_time >= t, 1) - 1;  % segment index (1..num)

    % t == 0 : return first waypoint
    if t == 0
        s_des(1:3) = waypoints(1,:);
        s_des(4:6) = 0;
        s_des(7:10) = [1;0;0;0];
        return;
    end

    if t_index > 1
        t = t - traj_time(t_index); % local time in the segment
    end

    % load coefficients
    px = pos_coeffs(:,1:8);   py = pos_coeffs(:,9:16);  pz = pos_coeffs(:,17:24);
    vx = vel_coeffs(:,1:8);   vy = vel_coeffs(:,9:16);  vz = vel_coeffs(:,17:24);

    % evaluate
    pos_x = polyval(flip(px(t_index,:)), t);
    pos_y = polyval(flip(py(t_index,:)), t);
    pos_z = polyval(flip(pz(t_index,:)), t);
    vel_x = polyval(flip(vx(t_index,:)), t);
    vel_y = polyval(flip(vy(t_index,:)), t);
    vel_z = polyval(flip(vz(t_index,:)), t);

    % output
    s_des(1:3) = [pos_x; pos_y; pos_z];
    s_des(4:6) = [vel_x; vel_y; vel_z];
    s_des(7:10) = [1;0;0;0];  % keep yaw flat; controller可仅用pos/vel
end
end

% --------- helpers ----------
function r = fact_ratio(n, k)
% n*(n-1)*...*(n-k+1) ; for k<=n, else 0
if n < k, r = 0; else r = factorial(n)/factorial(n-k); end
end

function row = dpoly_row(deg, r, t)
% row for d^r/dt^r of poly sum a_k t^k , k=0..deg
row = zeros(1,deg+1);
for k = r:deg
    row(k+1) = fact_ratio(k, r) * t^(k-r);
end
end
