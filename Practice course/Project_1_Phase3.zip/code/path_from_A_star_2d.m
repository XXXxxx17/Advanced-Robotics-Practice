function Optimal_path = path_from_A_star_2d(map2d)
% A* for pure 2D grids (4-neighborhood, 2D Manhattan heuristic)
% map2d: N×2, row1=start, rowN=target, rows 2..N-1 = obstacles (grid indices)
% return: Optimal_path (M×2), grid-center coords (index - 0.5)

Optimal_path = [];
if isempty(map2d) || size(map2d,2) ~= 2
    warning('Invalid 2D map. Expect N×2 [x y].'); return;
end

n = size(map2d,1);
xStart  = floor(map2d(1,1));  yStart  = floor(map2d(1,2));
xTarget = floor(map2d(n,1));  yTarget = floor(map2d(n,2));

% auto grid size to cover all indices
MAX_X = max(1, ceil(max(map2d(:,1))));
MAX_Y = max(1, ceil(max(map2d(:,2))));

% semantics: Obstacle=-1, Target=0, Start=1, Free=2
MAP = 2 * ones(MAX_X, MAX_Y);

% mark obstacles
for i = 2:n-1
    xi = floor(map2d(i,1)); yi = floor(map2d(i,2));
    if xi>=1 && xi<=MAX_X && yi>=1 && yi<=MAX_Y
        MAP(xi,yi) = -1;
    end
end

% bounds & collision checks
if any([xStart yStart] < 1) || xStart>MAX_X || yStart>MAX_Y
    warning('Start out of bound.'); return;
end
if any([xTarget yTarget] < 1) || xTarget>MAX_X || yTarget>MAX_Y
    warning('Target out of bound.'); return;
end
if MAP(xStart,yStart) == -1
    warning('Start is in obstacle.'); return;
end
if MAP(xTarget,yTarget) == -1
    warning('Target is in obstacle.'); return;
end

MAP(xStart,yStart)   = 1;
MAP(xTarget,yTarget) = 0;

% A* structures
queue = [];                              % [x y f]
g = inf(MAX_X, MAX_Y);
expanded = zeros(MAX_X, MAX_Y);
parents = zeros(MAX_X, MAX_Y, 2);        % store parent [px py]

% 4-neighbors (up/down/left/right in grid indices)
nbrs = [-1 0; 1 0; 0 -1; 0 1];

% heuristic: 2D Manhattan
hfun = @(x,y) abs(x - xTarget) + abs(y - yTarget);

% init
g(xStart,yStart) = 0;
queue = [queue; xStart yStart hfun(xStart,yStart)];

found = false;

while true
    if isempty(queue), break; end
    [~, idxMin] = min(queue(:,3));
    cur = queue(idxMin,1:2); queue(idxMin,:) = [];
    cx = cur(1); cy = cur(2);

    if expanded(cx,cy) == 1, continue; end
    expanded(cx,cy) = 1;

    if cx==xTarget && cy==yTarget
        found = true; break;
    end

    for k = 1:4
        nx = cx + nbrs(k,1);
        ny = cy + nbrs(k,2);
        if nx<1 || nx>MAX_X || ny<1 || ny>MAX_Y, continue; end
        if MAP(nx,ny) == -1, continue; end
        if expanded(nx,ny) == 1, continue; end

        tentative_g = g(cx,cy) + 1;   % unit step cost
        if tentative_g < g(nx,ny)
            g(nx,ny) = tentative_g;
            parents(nx,ny,:) = [cx cy];
            f = tentative_g + hfun(nx,ny);
            queue = [queue; nx ny f];
        end
    end
end

if ~found
    Optimal_path = []; return;
end

% backtrace
cur = [xTarget yTarget];
Optimal_path = cur;
while ~(cur(1)==xStart && cur(2)==yStart)
    p = squeeze(parents(cur(1),cur(2),:))';
    if all(p==0), Optimal_path = []; warning('Backtrace failed.'); return; end
    cur = p;
    Optimal_path = [cur; Optimal_path]; %#ok<AGROW>
end

% convert to grid-center coordinates (index - 0.5)
Optimal_path = Optimal_path - 0.5;
end
