function s_des = trajectory_generator(t, path, h, varargin)
% -------------------------------------------------------------------
% Minimum-snap trajectory generator (7th-order piecewise polynomials)
% - Init pass (nargin>1): pre-compute coefficients for all segments
% - Query pass (nargin==1): return desired state at time t
% 兼容 test_trajectory([], Optimal_path, h1, test_map) 的第4个参数（可选map）
% 输出:
%   s_des(1:3)  期望位置
%   s_des(4:6)  期望速度
%   s_des(7:10) 期望姿态(这里固定单位四元数)
%   s_des(11:13)期望加速度（新添，便于前馈）
% -------------------------------------------------------------------
persistent waypoints num traj_time time_interval pos_coeffs vel_coeffs acc_coeffs

s_des = zeros(13,1);
s_des(7:10) = [1;0;0;0];   % desired orientation: identity quat

% ===================== Part I: Initialization ======================
if nargin > 1
    % 必须：waypoints 至少两点
    waypoints = path;
    num = size(waypoints,1) - 1;                 
    if num < 1, error('Need at least 2 waypoints.'); end

    % ---- time allocation (按段长度分配时长) ----
    time_interval = zeros(num,1);
    for i = 1:num
        d = norm(waypoints(i+1,:) - waypoints(i,:));
        time_interval(i) = max(d, 1e-3);         % 避免0时长
    end
    traj_time = [0; cumsum(time_interval)];      % [0, T1, T1+T2, ..., Tend]

    % ---- build Q (∫ snap^2) and M (coeff -> boundary derivatives) ----
    Q = zeros(8*num, 8*num);
    M = zeros(8*num, 8*num);
    for i = 1:num
        T = time_interval(i);
        Qi = zeros(8,8);
        % 仅 a4..a7 影响四阶导
        for k = 4:7
            for l = 4:7
                ckl = fact_ratio(k,4) * fact_ratio(l,4) * T^(k+l-7)/(k+l-7);
                Qi(k+1,l+1) = ckl;
            end
        end
        idx = (i-1)*8 + (1:8);
        Q(idx,idx) = Qi;

        Mi = zeros(8,8);
        % t=0 处导数0..3
        for r = 0:3
            Mi(r+1,:) = dpoly_row(7, r, 0);
        end
        % t=T 处导数0..3
        for r = 0:3
            Mi(4+r+1,:) = dpoly_row(7, r, T);
        end
        M(idx,idx) = Mi;
    end

    % ---- selection matrix C：把“独立边界变量 d”映射到每段的“堆叠边界向量 D” ----
    % d = [每段起止位置(2N);
    %      起止边界的 v/a/j (6);
    %      内部 waypoint 的 v/a/j (k=2..N) (3*(N-1))]  总维度 = 5N+3
    nF = 2*num + 6;             
    nP = 3*(num - 1);           
    d_cols = nF + nP;           
    C = zeros(8*num, d_cols);

    % 列索引簿记
    pos_s_idx = zeros(num,1);   % 段 i 起点位置
    pos_e_idx = zeros(num,1);   % 段 i 终点位置
    col = 0;
    for i = 1:num
        col = col + 1; pos_s_idx(i) = col;
        col = col + 1; pos_e_idx(i) = col;
    end
    % 整体起止导数列
    col_v0 = col+1; col_a0 = col+2; col_j0 = col+3;
    col_vT = col+4; col_aT = col+5; col_jT = col+6;
    col = col + 6;

    % 内部 waypoint (2..num) 的 v/a/j
    v_int = zeros(num+1,1); a_int = zeros(num+1,1); j_int = zeros(num+1,1);
    for k = 2:num
        v_int(k) = col + 1; a_int(k) = col + 2; j_int(k) = col + 3;
        col = col + 3;
    end
    if col ~= d_cols
        error('C column count mismatch.');
    end

    % 填C (每段8行)
    for i = 1:num
        r0 = (i-1)*8;

        % 段 i 的起点 = waypoint i
        C(r0+1, pos_s_idx(i)) = 1;                   
        if i == 1
            C(r0+2, col_v0) = 1; C(r0+3, col_a0) = 1; C(r0+4, col_j0) = 1;
        else
            C(r0+2, v_int(i)) = 1; C(r0+3, a_int(i)) = 1; C(r0+4, j_int(i)) = 1;
        end

        % 段 i 的终点 = waypoint i+1
        C(r0+5, pos_e_idx(i)) = 1;                   
        if i == num
            C(r0+6, col_vT) = 1; C(r0+7, col_aT) = 1; C(r0+8, col_jT) = 1;
        else
            C(r0+6, v_int(i+1)) = 1; C(r0+7, a_int(i+1)) = 1; C(r0+8, j_int(i+1)) = 1;
        end
    end

    % ---- R = C' M^{-T} Q M^{-1} C，并解内点导数 d_P ----
    Minv = inv(M);
    R = C' * (Minv') * Q * Minv * C;

    R_FF = R(1:nF, 1:nF);
    R_PF = R(nF+1:end, 1:nF);
    R_PP = R(nF+1:end, nF+1:end);

    % 固定项 d_F（各轴分别填值；边界导数设0）
    d_Fx = zeros(nF,1); d_Fy = zeros(nF,1); d_Fz = zeros(nF,1);
    for i = 1:num
        d_Fx(pos_s_idx(i)) = waypoints(i,1);
        d_Fx(pos_e_idx(i)) = waypoints(i+1,1);
        d_Fy(pos_s_idx(i)) = waypoints(i,2);
        d_Fy(pos_e_idx(i)) = waypoints(i+1,2);
        d_Fz(pos_s_idx(i)) = waypoints(i,3);
        d_Fz(pos_e_idx(i)) = waypoints(i+1,3);
    end
    % 起止 v/a/j 已为零

    % 自由变量（内部导数）最优解
    d_Px = -(R_PP \ (R_PF * d_Fx));
    d_Py = -(R_PP \ (R_PF * d_Fy));
    d_Pz = -(R_PP \ (R_PF * d_Fz));

    d_x = [d_Fx; d_Px];
    d_y = [d_Fy; d_Py];
    d_z = [d_Fz; d_Pz];

    % ---- 多项式系数：p = M^{-1} C d ----
    p_x_vec = Minv * C * d_x;    % 长度 8*num，按段堆叠
    p_y_vec = Minv * C * d_y;
    p_z_vec = Minv * C * d_z;

    p_x = reshape(p_x_vec, 8, num)';   % num x 8, 存 [a0..a7]
    p_y = reshape(p_y_vec, 8, num)';
    p_z = reshape(p_z_vec, 8, num)';

    % 位置系数（直接存）
    pos_coeffs = [p_x, p_y, p_z];      % num x 24

    % 速度系数（1阶导，补零到8阶以便统一polyval）
    vx = [p_x(:,2), 2*p_x(:,3), 3*p_x(:,4), 4*p_x(:,5), 5*p_x(:,6), 6*p_x(:,7), 7*p_x(:,8), zeros(num,1)];
    vy = [p_y(:,2), 2*p_y(:,3), 3*p_y(:,4), 4*p_y(:,5), 5*p_y(:,6), 6*p_y(:,7), 7*p_y(:,8), zeros(num,1)];
    vz = [p_z(:,2), 2*p_z(:,3), 3*p_z(:,4), 4*p_z(:,5), 5*p_z(:,6), 6*p_z(:,7), 7*p_z(:,8), zeros(num,1)];
    vel_coeffs = [vx, vy, vz];

    % 加速度系数（2阶导，前两位为0）
    ax = [zeros(num,2), 2*p_x(:,3), 6*p_x(:,4), 12*p_x(:,5), 20*p_x(:,6), 30*p_x(:,7), 42*p_x(:,8)];
    ay = [zeros(num,2), 2*p_y(:,3), 6*p_y(:,4), 12*p_y(:,5), 20*p_y(:,6), 30*p_y(:,7), 42*p_y(:,8)];
    az = [zeros(num,2), 2*p_z(:,3), 6*p_z(:,4), 12*p_z(:,5), 20*p_z(:,6), 30*p_z(:,7), 42*p_z(:,8)];
    acc_coeffs = [ax, ay, az];

    % ---- 可视化（可选）：画轨迹与（若提供）障碍点 ----
    if ~isempty(h)
        subplot(h); hold on; grid on; axis equal
        % 轨迹采样
        Px = []; Py = []; Pz = [];
        for i = 1:num
            T = time_interval(i);
            tt = 0:0.01:T;
            Px = [Px polyval(flip(p_x(i,:)), tt)]; %#ok<AGROW>
            Py = [Py polyval(flip(p_y(i,:)), tt)];
            Pz = [Pz polyval(flip(p_z(i,:)), tt)];
        end
        plot3(Px, Py, Pz, 'r-', 'LineWidth', 2);
        plot3(waypoints(:,1), waypoints(:,2), waypoints(:,3), 'bo--','MarkerFaceColor','b');
        % 如果传入了地图，把障碍/起终点标出来
        if ~isempty(varargin)
            m = varargin{1};
            if size(m,2) >= 3
                if size(m,1) >= 2
                    obs = m(2:end-1,:); % 中间行视为障碍
                    if ~isempty(obs)
                        plot3(obs(:,1),obs(:,2),obs(:,3),'ks','MarkerFaceColor','k','MarkerSize',6);
                    end
                end
                plot3(m(1,1),m(1,2),m(1,3),'gp','MarkerSize',12,'MarkerFaceColor','g');              % start
                plot3(m(end,1),m(end,2),m(end,3),'mp','MarkerSize',12,'MarkerFaceColor','m');         % goal
            end
        end
        hold off;
    end

% ===================== Part II: Query ======================
else
    % 边界保护
    if t < 0, t = 0; end
    if t > traj_time(end), t = traj_time(end); end

    % 找到 t 所在的段索引：t ∈ [traj_time(i), traj_time(i+1)]
    t_index = find(traj_time <= t, 1, 'last');
    if t_index == num+1
        seg = num; t_local = time_interval(num);   % 最后时刻：用最后一段的 T
    else
        seg = max(1, t_index);
        t_local = t - traj_time(seg);              % 段内时间
    end

    % t == 0 : 直接返回第一个点
    if t == 0
        s_des(1:3) = waypoints(1,:);
        s_des(4:6) = 0;
        s_des(11:13)= 0;
        return;
    end

    % 取系数
    px = pos_coeffs(:,1:8);   py = pos_coeffs(:,9:16);  pz = pos_coeffs(:,17:24);
    vx = vel_coeffs(:,1:8);   vy = vel_coeffs(:,9:16);  vz = vel_coeffs(:,17:24);
    ax = acc_coeffs(:,1:8);   ay = acc_coeffs(:,9:16);  az = acc_coeffs(:,17:24);

    % 多项式求值
    pos_x = polyval(flip(px(seg,:)), t_local);
    pos_y = polyval(flip(py(seg,:)), t_local);
    pos_z = polyval(flip(pz(seg,:)), t_local);
    vel_x = polyval(flip(vx(seg,:)), t_local);
    vel_y = polyval(flip(vy(seg,:)), t_local);
    vel_z = polyval(flip(vz(seg,:)), t_local);
    acc_x = polyval(flip(ax(seg,:)), t_local);
    acc_y = polyval(flip(ay(seg,:)), t_local);
    acc_z = polyval(flip(az(seg,:)), t_local);

    % 输出
    s_des(1:3)   = [pos_x; vel_y*0+pos_y; pos_z];   %（保持与你原布局一致）
    s_des(4:6)   = [vel_x; vel_y; vel_z];
    s_des(7:10)  = [1;0;0;0];                       % 需要航向时可改成 yaw->quat
    s_des(11:13) = [acc_x; acc_y; acc_z];           % 新增：加速度前馈
end
end

% --------- helpers ----------
function r = fact_ratio(n, k)
% n*(n-1)*...*(n-k+1) ; for k<=n, else 0
if n < k, r = 0; else r = factorial(n)/factorial(n-k); end
end

function row = dpoly_row(deg, r, t)
% row for d^r/dt^r of poly sum a_k t^k , k=0..deg
row = zeros(1,deg+1);
for k = r:deg
    row(k+1) = fact_ratio(k, r) * t^(k-r);
end
end
