% Used for HKUST ELEC 5660 — Pure 2D maps + 3D trajectory/flight pipeline

close all; clear; clc;
addpath('./utils','./readonly');   % 保持与原工程一致

% ---------- 子图布局 ----------
h1 = subplot(3,3,1);  h2 = subplot(3,3,2);  h3 = subplot(3,3,3);
h4 = subplot(3,3,4);  h5 = subplot(3,3,5);  h6 = subplot(3,3,6);
h7 = subplot(3,3,7);  h8 = subplot(3,3,8);  h9 = subplot(3,3,9);
set(gcf,'Renderer','painters'); set(gcf,'Position',[100 100 1400 1000]);

% ============================================================
%                 纯 2D 地图（仅两列 x,y）
% 规则：第1行=start，最后1行=goal，中间行为障碍（整点网格）
% ============================================================

% 2D Map A：中部障碍块 + 右侧竖栏，形成绕行
map2d_A = [
    1 1;            % start
    % obstacles
    2 2; 3 2; 4 2;
    2 3; 3 3; 4 3;
    7 2; 7 3; 7 4;
    8 6; 9 6;
    10 9           % goal
];

% 2D Map B：L 型走廊 + 中部横梁（留缺口）
map2d_B = [
    1 1;            % start
    % obstacles
    3 1; 4 1; 5 1; 6 1; 7 1;        % 下方一排（留 2→3 的通道）
    3 2; 3 3; 3 4; 3 5;             % 左侧竖排
    6 4; 7 4; 8 4; 9 4;             % 中部横梁（留 x=5 缺口）
    9 7; 9 8;                        % 右上两块
    10 10          % goal
];

% 选择要跑的 2D 地图
test_map_2d = map2d_A;   % ← 改成 map2d_B 可切换第二张

% ============================================================
%                   2D A* → 3D 轨迹/仿真
% ============================================================

% 1) 用纯2D A* 求离散航点（返回 M×2，坐标为“格中心”）
Optimal_path_2d = path_from_A_star_2d(test_map_2d);
if isempty(Optimal_path_2d)
    error('A* (2D) 未找到可行路径，请检查2D地图的起终点与障碍设置。');
end

% 2) 接口处升到 3D：z 固定为格中心 0.5（不改变“建图是纯2D”的事实）
Optimal_path = [Optimal_path_2d, 0.5*ones(size(Optimal_path_2d,1),1)];

% 3) 仅用于可视化障碍/起终点（h1 上画图）：把 2D 地图补一个 z=1
%    注意：这只是画图需要；你的建图与A*仍然是纯2D
test_map_for_vis = [test_map_2d, ones(size(test_map_2d,1),1)];

% 4) 轨迹初始化（最小 snap），在 h1 上可视化航点/轨迹/障碍
trajectory_generator([], Optimal_path, h1, test_map_for_vis);

% 5) 跑仿真（SE(3) 动力学 + 控制器）
run_trajectory_readonly(h1,h2,h3,h4,h5,h6,h7,h8,h9);

% （可选）小检查：确认路径 z 被锁定在同一层（0.5）
% disp(unique(Optimal_path(:,3)));
