function Optimal_path = path_from_A_star(map)
% A* path search supporting both 2D (4-neigh) and 3D (6-neigh)
% map: N×3, row1=start, rowN=target, rows 2..N-1 = obstacles (grid coords)
% Return: Optimal_path (M×3), in grid-center coordinates (index - 0.5)

Optimal_path = [];
if isempty(map) || size(map,2) < 3
    warning('Invalid map. Expect N×3.');
    return;
end

size_map = size(map,1);

% ====== 自动网格尺寸（至少覆盖 map 的最大索引；不小于 1） ======
MAX_X = max(1, ceil(max(map(:,1))));
MAX_Y = max(1, ceil(max(map(:,2))));
MAX_Z = max(1, ceil(max(map(:,3))));

% ====== MAP 语义：Obstacle=-1, Target=0, Start=1, Free=2 ======
MAP = 2 * ones(MAX_X, MAX_Y, MAX_Z);

% --- 起点 / 终点（取整到格点索引）---
xStart  = floor(map(1,1));   yStart  = floor(map(1,2));   zStart  = floor(map(1,3));
xTarget = floor(map(size_map,1)); yTarget = floor(map(size_map,2)); zTarget = floor(map(size_map,3));

% 越界保护
if any([xStart yStart zStart] < 1) || xStart>MAX_X || yStart>MAX_Y || zStart>MAX_Z
    warning('Start out of bound.'); return;
end
if any([xTarget yTarget zTarget] < 1) || xTarget>MAX_X || yTarget>MAX_Y || zTarget>MAX_Z
    warning('Target out of bound.'); return;
end

MAP(xTarget, yTarget, zTarget) = 0;

% --- 障碍（第2行到倒数第2行）---
for i = 2 : size_map-1
    xi = floor(map(i,1)); yi = floor(map(i,2)); zi = floor(map(i,3));
    if xi>=1 && xi<=MAX_X && yi>=1 && yi<=MAX_Y && zi>=1 && zi<=MAX_Z
        MAP(xi,yi,zi) = -1;
    end
end

MAP(xStart, yStart, zStart) = 1;

% 起终点不得在障碍上
if MAP(xStart,yStart,zStart) == -1
    warning('Start is in obstacle.'); return;
end
if MAP(xTarget,yTarget,zTarget) == -1
    warning('Target is in obstacle.'); return;
end

% ====== 模式判定：2D or 3D ======
is2D = all(abs(map(:,3) - map(1,3)) < 1e-9);   % 所有 z 相同则视为 2D
zPlane = zStart;                                % 2D 平面所在的 z

% 邻接与启发函数
if is2D
    % 4 邻接（上下左右），只允许在同一 z 平面运动
    nbrs = [-1 0 0;
             1 0 0;
             0 -1 0;
             0  1 0];
    hfun = @(x,y,~,xT,yT,~) abs(x-xT) + abs(y-yT);          % 2D 曼哈顿
else
    % 6 邻接（±x/±y/±z）
    nbrs = [-1 0 0;
             1 0 0;
             0 -1 0;
             0  1 0;
             0  0 -1;
             0  0  1];
    hfun = @(x,y,z,xT,yT,zT) abs(x-xT) + abs(y-yT) + abs(z-zT); % 3D 曼哈顿
end

% ====== A* 数据结构 ======
% open表：每行 [x y z f]
queue = [];
% g 代价：未发现为 inf
g = inf(MAX_X, MAX_Y, MAX_Z);
% closed 标记
expanded = zeros(MAX_X, MAX_Y, MAX_Z);
% 父节点（回溯用）
parents = zeros(MAX_X, MAX_Y, MAX_Z, 3);

% 起点入队
g(xStart,yStart,zStart) = 0;
h0 = hfun(xStart,yStart,zStart, xTarget,yTarget,zTarget);
queue = [queue; xStart yStart zStart h0];

found = false;

% ====== 主循环 ======
while true
    % 队列空：不可达
    if isempty(queue), break; end

    % 取 f 最小的节点（可加次级 tie-breaker，这里简化）
    [~, idxMin] = min(queue(:,4));
    cur = queue(idxMin, 1:3);
    queue(idxMin, :) = [];

    cx = cur(1); cy = cur(2); cz = cur(3);

    % 已在 closed 则跳过
    if expanded(cx,cy,cz) == 1, continue; end
    expanded(cx,cy,cz) = 1;

    % 命中目标
    if cx==xTarget && cy==yTarget && cz==zTarget
        found = true;
        break;
    end

    % 扩展相邻
    for k = 1:size(nbrs,1)
        nx = cx + nbrs(k,1);
        ny = cy + nbrs(k,2);
        nz = cz + nbrs(k,3);

        % 2D 模式禁止离开 z 平面
        if is2D && nz ~= zPlane, continue; end

        % 边界 / 障碍 / 已扩展 过滤
        if nx<1 || nx>MAX_X || ny<1 || ny>MAX_Y || nz<1 || nz>MAX_Z, continue; end
        if MAP(nx,ny,nz) == -1, continue; end
        if expanded(nx,ny,nz) == 1, continue; end

        % 单位步长代价
        tentative_g = g(cx,cy,cz) + 1;

        if tentative_g < g(nx,ny,nz)
            g(nx,ny,nz) = tentative_g;
            parents(nx,ny,nz,:) = [cx cy cz];
            h = hfun(nx,ny,nz, xTarget,yTarget,zTarget);
            f = tentative_g + h;
            queue = [queue; nx ny nz f];
        end
    end
end

% ====== 回溯路径 ======
if ~found
    Optimal_path = []; % 不可达
    return;
end

cur_pos = [xTarget yTarget zTarget];
Optimal_path = cur_pos;
while ~(cur_pos(1)==xStart && cur_pos(2)==yStart && cur_pos(3)==zStart)
    p = squeeze(parents(cur_pos(1), cur_pos(2), cur_pos(3), :))';
    if all(p==0)
        Optimal_path = [];
        warning('Backtrace failed: missing parents.');
        return;
    end
    cur_pos = p;
    Optimal_path = [cur_pos; Optimal_path]; %#ok<AGROW>
end

% 将格点索引转为网格中心坐标（索引 - 0.5）
Optimal_path = Optimal_path - 0.5;
end
