function test_trajectory
% HNU RO10005 - Project 1 Phase 1
% Clean test harness for running one trajectory and printing controller stats.

close all; clc;

%% === 路径设置（以本文件所在目录为根） ===
root = fileparts(mfilename('fullpath'));
addpath(fullfile(root,'utils'), fullfile(root,'readonly'));

%% === 图窗与子图（run_trajectory_readonly 需要这些句柄） ===
fig = figure('Name','RO10005 P1','NumberTitle','off');
set(fig,'Renderer','opengl');   % 比 painters 更流畅

h1  = subplot(3,4,1,'Parent',fig);
h2  = subplot(3,4,2,'Parent',fig);
h3  = subplot(3,4,3,'Parent',fig);
h4  = subplot(3,4,4,'Parent',fig);
h5  = subplot(3,4,6,'Parent',fig);
h6  = subplot(3,4,7,'Parent',fig);
h7  = subplot(3,4,8,'Parent',fig);
h8  = subplot(3,4,10,'Parent',fig);
h9  = subplot(3,4,11,'Parent',fig);
h10 = subplot(3,4,12,'Parent',fig);

%% === 选择要运行的轨迹（按需改这一行） ===
traj_handle = @circle_trajectory;           % 圆轨
% traj_handle = @diamond_trajectory;        % 菱形轨
% traj_handle = @hover_trajectory;          % 悬停
% traj_handle = @neon_silhouette_trajectory;% 霓虹轮廓（若已放入 code/ 目录）

%% === 运行前：清空全局误差缓存（供控制器记录 RMS 用） ===
global rms_xposition rms_xvelocity rms_yposition rms_yvelocity rms_zposition rms_zvelocity
rms_xposition = []; rms_xvelocity = [];
rms_yposition = []; rms_yvelocity = [];
rms_zposition = []; rms_zvelocity = [];

%% === 运行仿真（只跑一次） ===
% run_trajectory_readonly(h1,h2,h3,h4,h5,h6,h7,h8,h9,h10, @diamond_trajectory);
% run_trajectory_readonly(h1,h2,h3,h4,h5,h6,h7,h8,h9,h10, @circle_trajectory);
% run_trajectory_readonly(h1,h2,h3,h4,h5,h6,h7,h8,h9,h10, @hover_trajectory);
run_trajectory_readonly(h1,h2,h3,h4,h5,h6,h7,h8,h9,h10, @caixvkun_trajectory);
%% === 运行后：统计 (b) RMS 指标 ===
% 单轴 RMS
rmse_pos_xyz = [rms(rms_xposition), rms(rms_yposition), rms(rms_zposition)];
rmse_vel_xyz = [rms(rms_xvelocity), rms(rms_yvelocity), rms(rms_zvelocity)];

% 3D 合成 RMS（逐时刻 3D 误差范数 -> 均值 -> 开方）
pos_norm = hypot(hypot(rms_xposition, rms_yposition), rms_zposition);
vel_norm = hypot(hypot(rms_xvelocity, rms_yvelocity), rms_zvelocity);
rmse_pos_3D = sqrt(mean(pos_norm.^2));
rmse_vel_3D = sqrt(mean(vel_norm.^2));

% 95 分位与最大误差（无统计工具箱也能执行）
p95_pos = pctl95(pos_norm);
p95_vel = pctl95(vel_norm);
max_pos = max(pos_norm);
max_vel = max(vel_norm);

% 打印
fprintf('\n=== RMS 统计（%s）===\n', func2str(traj_handle));
fprintf('Position RMS [x y z] (m): [%.3f %.3f %.3f]\n', rmse_pos_xyz);
fprintf('Velocity RMS [x y z] (m/s): [%.3f %.3f %.3f]\n', rmse_vel_xyz);
fprintf('Position RMS 3D (m): %.3f, 95th=%.3f, max=%.3f\n', rmse_pos_3D, p95_pos, max_pos);
fprintf('Velocity RMS 3D (m/s): %.3f, 95th=%.3f, max=%.3f\n', rmse_vel_3D, p95_vel, max_vel);

end

%% === 辅助函数：RMS 与 95 分位（无依赖版本） ===
function v = rms(x)
if isempty(x), v = 0; else, v = sqrt(mean(x.^2)); end
end

function p = pctl95(x)
% 兼容无统计工具箱的环境
x = x(:);
if isempty(x), p = 0; return; end
if exist('prctile','file') == 2
    p = prctile(x,95);
elseif exist('quantile','file') == 2
    p = quantile(x,0.95);
else
    xs = sort(x);
    k = max(1, min(numel(xs), round(0.95*numel(xs))));
    p = xs(k);
end
end
