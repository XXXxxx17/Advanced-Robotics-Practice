#include <iostream>
#include <math.h>

#include <ros/ros.h>
#include <ros/console.h>
#include <sensor_msgs/Image.h>
#include <sensor_msgs/image_encodings.h>
#include <cv_bridge/cv_bridge.h>
#include <nav_msgs/Path.h>
#include <nav_msgs/Odometry.h>
#include <geometry_msgs/PoseStamped.h>
#include <visualization_msgs/Marker.h>

#include <aruco/aruco.h>
#include <aruco/cvdrawingutils.h>
#include <opencv2/opencv.hpp>

#include <Eigen/Eigen>
#include <Eigen/Dense>
#include <Eigen/SVD>
#include <Eigen/Geometry>
#include <opencv2/core/eigen.hpp>

using namespace cv;
using namespace aruco;
using namespace Eigen;

// ======================= ȫ���� =======================
double reproj_error;
MatrixXd cum_error = MatrixXd::Zero(6, 1);
int count_frame = 0;

// �������
aruco::CameraParameters CamParam;
cv::Mat K, D;

// ArUco
MarkerDetector MDetector;
vector<Marker> Markers;
float MarkerSize = 0.20f / 1.5f * 1.524f;
float MarkerWithMargin = MarkerSize * 1.2f;
BoardConfiguration TheBoardConfig;
BoardDetector TheBoardDetector;
Board TheBoardDetected;

// ROS
ros::Subscriber sub_img;
ros::Publisher pub_path_ref, pub_path;
ros::Publisher pub_odom_ref, pub_odom;
ros::Publisher pub_arrow_ref, pub_arrow;
nav_msgs::Path path_ref, path;

// ============= ƽ��/�޷����� =============
const double ALPHA_POS = 0.25;                    
const double ALPHA_ROT = 0.25;                   
const double MAX_TRANS_JUMP = 0.12;              
const double MAX_ROT_JUMP_RAD = 10.0 * M_PI / 180.0;  

// ============= �����оݣ���ֹ/ʧ�䣩 =============
const int    MIN_INLIERS = 20;            
const double REPROJ_MAX_PX = 2.5;             
const double STILL_TRANS_THRES = 0.002;           
const double STILL_ROT_THRES = 0.3 * M_PI / 180.0;  
const double ARROW_LEN = 0.25;          

// ======================= С���� =======================
static inline Matrix3d Skew(const Vector3d& v) {
    Matrix3d S; S << 0, -v.z(), v.y(), v.z(), 0, -v.x(), -v.y(), v.x(), 0; return S;
}
static inline double rotationAngle(const Matrix3d& R1, const Matrix3d& R2) {
    Matrix3d R = R1.transpose() * R2;
    double tr = (R.trace() - 1.0) * 0.5; tr = std::max(-1.0, std::min(1.0, tr));
    return acos(tr);
}

// �켣ƽ������֧���޷� + EMA/SLERP��
struct PoseSmoother {
    bool has = false;
    Matrix3d Rwc = Matrix3d::Identity();
    Vector3d twc = Vector3d::Zero();

    void clampJump(Matrix3d& R_in, Vector3d& t_in) {
        if (!has) return;
        // ƽ���޷�
        Vector3d d = t_in - twc;
        double dn = d.norm();
        if (dn > MAX_TRANS_JUMP && dn > 1e-9) t_in = twc + (MAX_TRANS_JUMP / dn) * d;
        // ��ת�޷�
        double ang = rotationAngle(Rwc, R_in);
        if (ang > MAX_ROT_JUMP_RAD) {
            Quaterniond q0(Rwc), q1(R_in); if (q0.dot(q1) < 0) q1.coeffs() *= -1.;
            double r = MAX_ROT_JUMP_RAD / ang;
            Quaterniond qs = q0.slerp(r, q1);
            R_in = qs.normalized().toRotationMatrix();
        }
    }

    void update(const Matrix3d& R_in_raw, const Vector3d& t_in_raw,
        Matrix3d& R_out, Vector3d& t_out)
    {
        Matrix3d R_in = R_in_raw; Vector3d t_in = t_in_raw;
        if (has) clampJump(R_in, t_in);

        if (!has) { Rwc = R_in; twc = t_in; has = true; }
        else {
            // ��Ԫ��ͬ�� + SLERP
            Quaterniond q0(Rwc), q1(R_in); if (q0.dot(q1) < 0) q1.coeffs() *= -1.;
            Quaterniond q = q0.slerp(ALPHA_ROT, q1);
            Rwc = q.normalized().toRotationMatrix();
            // ƽ�� EMA
            twc = (1.0 - ALPHA_POS) * twc + ALPHA_POS * t_in;
        }
        R_out = Rwc; t_out = twc;
    }
};

// ����ƽ�������ο��켣/��Ĺ켣
PoseSmoother smooth_ref, smooth_mine;

// ======================= �������� =======================
void publishPath(const ros::Time& t, const Vector3d& T, const Quaterniond& Q,
    nav_msgs::Path& path_out, ros::Publisher& pub_out)
{
    geometry_msgs::PoseStamped ps;
    ps.header.stamp = t; ps.header.frame_id = "world";
    ps.pose.position.x = T(0); ps.pose.position.y = T(1); ps.pose.position.z = T(2);
    ps.pose.orientation.x = Q.x(); ps.pose.orientation.y = Q.y();
    ps.pose.orientation.z = Q.z(); ps.pose.orientation.w = Q.w();

    path_out.header.stamp = t; path_out.header.frame_id = "world";
    path_out.poses.push_back(ps);
    pub_out.publish(path_out);
}

void publishOdom(const ros::Time& t, const Vector3d& T, const Quaterniond& Q,
    ros::Publisher& pub_odom, const std::string& child = "camera")
{
    nav_msgs::Odometry odom;
    odom.header.stamp = t; odom.header.frame_id = "world";
    odom.child_frame_id = child;
    odom.pose.pose.position.x = T(0);
    odom.pose.pose.position.y = T(1);
    odom.pose.pose.position.z = T(2);
    odom.pose.pose.orientation.x = Q.x();
    odom.pose.pose.orientation.y = Q.y();
    odom.pose.pose.orientation.z = Q.z();
    odom.pose.pose.orientation.w = Q.w();
    pub_odom.publish(odom);
}

void publishArrow(const ros::Time& t, const Matrix3d& Rwc, const Vector3d& T,
    ros::Publisher& pub_marker, double r, double g, double b)
{
    visualization_msgs::Marker m;
    m.header.frame_id = "world";
    m.header.stamp = t;
    m.ns = "tag_detector_axis";
    m.id = (pub_marker == pub_arrow ? 1 : 0); 
    m.type = visualization_msgs::Marker::ARROW;
    m.action = visualization_msgs::Marker::ADD;
    m.lifetime = ros::Duration(0.1); 

    // ARROW: points[0]=tail, points[1]=head; scale.x=��ֱ��, y=��ͷֱ��, z=��ͷ����
    m.scale.x = 0.02; m.scale.y = 0.04; m.scale.z = 0.08;
    m.color.r = r; m.color.g = g; m.color.b = b; m.color.a = 1.0;

    geometry_msgs::Point p0, p1;
    p0.x = T(0); p0.y = T(1); p0.z = T(2);
    Vector3d dir = Rwc * Vector3d(0, 0, 1); 
    Vector3d P1 = T + ARROW_LEN * dir;
    p1.x = P1(0); p1.y = P1(1); p1.z = P1(2);

    m.points.clear();
    m.points.push_back(p0);
    m.points.push_back(p1);

    pub_marker.publish(m);
}

// ======================= ��� 3D �㣨Z=0�� =======================
cv::Point3f getPositionFromIndex(int idx, int nth)
{
    int idx_x = idx % 6, idx_y = idx / 6;
    double p_x = idx_x * MarkerWithMargin - (3 + 2.5 * 0.2) * MarkerSize;
    double p_y = idx_y * MarkerWithMargin - (12 + 11.5 * 0.2) * MarkerSize;
    return cv::Point3f(p_x + (nth == 1 || nth == 2) * MarkerSize,
        p_y + (nth == 2 || nth == 3) * MarkerSize, 0.0);
}

// ======================= ��ͶӰ��� =======================
void calculateReprojectionError(const vector<cv::Point3f>& pts_3,
    const vector<cv::Point2f>& pts_2,
    const cv::Mat R, const cv::Mat t)
{
    if (pts_3.size() != pts_2.size() || pts_3.size() < 4) { reproj_error = -1; return; }
    cv::Mat rvec; cv::Rodrigues(R, rvec);
    vector<cv::Point2f> proj; cv::projectPoints(pts_3, rvec, t, K, D, proj);
    double sse = 0.0;
    for (size_t i = 0; i < pts_2.size(); ++i) { cv::Point2f e = proj[i] - pts_2[i]; sse += e.x * e.x + e.y * e.y; }
    reproj_error = std::sqrt(sse / std::max<size_t>(1, pts_2.size()));
}

// ======================= λ�˹��ƣ��Ƚ� + ���� + ˫�켣ƽ���� =======================
void process(const vector<int>& /*pts_id*/,
    const vector<cv::Point3f>& pts_3,
    const vector<cv::Point2f>& pts_2,
    const ros::Time& frame_time)
{
    if (pts_3.size() < 6) return;

    // ---------- �ο���OpenCV PnP (RANSAC) ----------
    cv::Mat rvec_ref, tvec_ref, inlierMask;
    bool ok_ref = cv::solvePnPRansac(pts_3, pts_2, K, D, rvec_ref, tvec_ref,
        false, 100, 3.0, 0.99, inlierMask,
        cv::SOLVEPNP_AP3P);
    if (!ok_ref) return;

    const int inliers = inlierMask.empty() ? (int)pts_3.size() : cv::countNonZero(inlierMask);

    cv::Mat R_ref_cv; cv::Rodrigues(rvec_ref, R_ref_cv);
    Matrix3d Rcw_ref; cv::cv2eigen(R_ref_cv, Rcw_ref);
    Vector3d tcw_ref(tvec_ref.at<double>(0), tvec_ref.at<double>(1), tvec_ref.at<double>(2));

    Matrix3d Rwc_ref_raw = Rcw_ref.transpose();      
    Vector3d twc_ref_raw = -Rcw_ref.transpose() * tcw_ref;

    // �ο���ͶӰ��px��
    calculateReprojectionError(pts_3, pts_2, R_ref_cv, tvec_ref);
    double reproj_ref_px = reproj_error;

    // ֻ���ڵ����Ż�
    std::vector<cv::Point3f> P3_inl;
    std::vector<cv::Point2f> p2_inl;
    if (!inlierMask.empty()) {
        for (int i = 0; i < inlierMask.rows; i++)
            if (inlierMask.at<uchar>(i)) { P3_inl.push_back(pts_3[i]); p2_inl.push_back(pts_2[i]); }
    }
    if (P3_inl.size() < 6) { P3_inl = pts_3; p2_inl = pts_2; }

    cv::Mat rvec_init, tvec_init; 
    cv::solvePnP(P3_inl, p2_inl, K, D, rvec_init, tvec_init, false, cv::SOLVEPNP_EPNP);
    cv::Mat Rcv_init; cv::Rodrigues(rvec_init, Rcv_init);
    Matrix3d Rcw = Matrix3d::Identity(); cv::cv2eigen(Rcv_init, Rcw);
    Vector3d tcw(tvec_init.at<double>(0), tvec_init.at<double>(1), tvec_init.at<double>(2));

    // ��һ���۲�
    std::vector<cv::Point2f> und; cv::undistortPoints(p2_inl, und, K, D);

    const int max_iters = 12; const double eps = 1e-9; const double huber = 0.01;
    for (int it = 0; it < max_iters; ++it) {
        Matrix<double, 6, 6> H = Matrix<double, 6, 6>::Zero();
        Matrix<double, 6, 1> b = Matrix<double, 6, 1>::Zero();
        for (size_t i = 0; i < P3_inl.size(); ++i) {
            Vector3d Pw(P3_inl[i].x, P3_inl[i].y, P3_inl[i].z);
            Vector3d Pc = Rcw * Pw + tcw; double X = Pc(0), Y = Pc(1), Z = Pc(2); if (Z < 1e-6) continue;
            Vector2d r; r << (und[i].x - X / Z), (und[i].y - Y / Z);
            double e = r.norm(); double w = (e <= huber) ? 1.0 : (huber / e);

            Matrix<double, 2, 3> Jp; Jp << 1.0 / Z, 0, -X / (Z * Z), 0, 1.0 / Z, -Y / (Z * Z);
            Matrix<double, 3, 6> Jx; Jx.leftCols<3>() = Matrix3d::Identity(); Jx.rightCols<3>() = -Skew(Pc);
            Matrix<double, 2, 6> J = Jp * Jx;
            H += w * (J.transpose() * J); b += w * (J.transpose() * r);
        }
        Matrix<double, 6, 1> dx = H.ldlt().solve(b);
        if (!dx.allFinite() || dx.norm() < eps) break;
        Vector3d dv = dx.head<3>(), w = dx.tail<3>();
        double th = w.norm(); Matrix3d dR = Matrix3d::Identity();
        if (th > 1e-12) { Vector3d a = w / th; Matrix3d A = Skew(a); dR = Matrix3d::Identity() + sin(th) * A + (1 - cos(th)) * (A * A); }
        Rcw = dR * Rcw; tcw = dR * tcw + dv;
    }
    if (tcw(2) < 0) { Rcw = -Rcw; tcw = -tcw; } 

    Matrix3d Rwc_raw = Rcw.transpose();
    Vector3d twc_raw = -Rcw.transpose() * tcw;

    // ��Ľ���ͶӰ��px��
    Matrix3d Rcw_est = Rwc_raw.transpose();
    Vector3d tcw_est = -Rcw_est * twc_raw;
    cv::Mat R_est_cw_cv(3, 3, CV_64F), t_est_cw_cv(3, 1, CV_64F);
    cv::eigen2cv(Rcw_est, R_est_cw_cv);
    t_est_cw_cv.at<double>(0) = tcw_est(0); t_est_cw_cv.at<double>(1) = tcw_est(1); t_est_cw_cv.at<double>(2) = tcw_est(2);
    calculateReprojectionError(pts_3, pts_2, R_est_cw_cv, t_est_cw_cv);
    double reproj_mine_px = reproj_error;

    // ---------- ���ӻ���ƽ�� + ���� ----------
    // �ο������ߣ�
    Matrix3d Rwc_ref_viz; Vector3d twc_ref_viz;
    bool hold_ref = false;
    if (smooth_ref.has) {
        double dt = (twc_ref_raw - smooth_ref.twc).norm();
        double dang = rotationAngle(smooth_ref.Rwc, Rwc_ref_raw);
        hold_ref = (inliers < MIN_INLIERS) || (reproj_ref_px > REPROJ_MAX_PX)
            || (dt < STILL_TRANS_THRES && dang < STILL_ROT_THRES);
    }
    if (hold_ref) { Rwc_ref_viz = smooth_ref.Rwc; twc_ref_viz = smooth_ref.twc; }
    else { smooth_ref.update(Rwc_ref_raw, twc_ref_raw, Rwc_ref_viz, twc_ref_viz); }

    publishPath(frame_time, twc_ref_viz, Quaterniond(Rwc_ref_viz), path_ref, pub_path_ref);
    publishOdom(frame_time, twc_ref_viz, Quaterniond(Rwc_ref_viz), pub_odom_ref, "cam_ref");
    publishArrow(frame_time, Rwc_ref_viz, twc_ref_viz, pub_arrow_ref, 1.0, 0.2, 0.2); 

    // ����
    Matrix3d Rwc_viz; Vector3d twc_viz;
    bool hold_mine = false;
    if (smooth_mine.has) {
        double dt = (twc_raw - smooth_mine.twc).norm();
        double dang = rotationAngle(smooth_mine.Rwc, Rwc_raw);
        hold_mine = (inliers < MIN_INLIERS) || (reproj_mine_px > REPROJ_MAX_PX)
            || (dt < STILL_TRANS_THRES && dang < STILL_ROT_THRES);
    }
    if (hold_mine) { Rwc_viz = smooth_mine.Rwc; twc_viz = smooth_mine.twc; }
    else { smooth_mine.update(Rwc_raw, twc_raw, Rwc_viz, twc_viz); }

    publishPath(frame_time, twc_viz, Quaterniond(Rwc_viz), path, pub_path);
    publishOdom(frame_time, twc_viz, Quaterniond(Rwc_viz), pub_odom, "cam_yourwork");
    publishArrow(frame_time, Rwc_viz, twc_viz, pub_arrow, 0.1, 0.9, 0.1);

    // ---------- ���ͳ�ƣ�raw �� raw�� ----------
    double dpsi = Rwc_ref_raw.eulerAngles(2, 0, 1)(0) - Rwc_raw.eulerAngles(2, 0, 1)(0);
    if (dpsi > M_PI) dpsi -= 2 * M_PI; else if (dpsi < -M_PI) dpsi += 2 * M_PI;
    double dphi = Rwc_ref_raw.eulerAngles(2, 0, 1)(1) - Rwc_raw.eulerAngles(2, 0, 1)(1);
    if (dphi > M_PI) dphi -= 2 * M_PI; else if (dphi < -M_PI) dphi += 2 * M_PI;
    double dtheta = Rwc_ref_raw.eulerAngles(2, 0, 1)(2) - Rwc_raw.eulerAngles(2, 0, 1)(2);
    if (dtheta > M_PI) dtheta -= 2 * M_PI; else if (dtheta < -M_PI) dtheta += 2 * M_PI;

    count_frame++;
    cum_error(0, 0) += dpsi * dpsi;   cum_error(1, 0) += dphi * dphi;   cum_error(2, 0) += dtheta * dtheta;
    cum_error(3, 0) += (twc_ref_raw(0) - twc_raw(0)) * (twc_ref_raw(0) - twc_raw(0));
    cum_error(4, 0) += (twc_ref_raw(1) - twc_raw(1)) * (twc_ref_raw(1) - twc_raw(1));
    cum_error(5, 0) += (twc_ref_raw(2) - twc_raw(2)) * (twc_ref_raw(2) - twc_raw(2));

    ROS_INFO("RMSE  T(x,y,z)= %.4f, %.4f, %.4f | R(roll,pitch,yaw)= %.4f, %.4f, %.4f | inliers=%d | reproj(px) ref=%.2f mine=%.2f",
        sqrt(cum_error(3, 0) / count_frame), sqrt(cum_error(4, 0) / count_frame), sqrt(cum_error(5, 0) / count_frame),
        sqrt(cum_error(1, 0) / count_frame), sqrt(cum_error(2, 0) / count_frame), sqrt(cum_error(0, 0) / count_frame),
        inliers, reproj_ref_px, reproj_mine_px);
}

// ======================= ͼ��ص� =======================
void img_callback(const sensor_msgs::ImageConstPtr& img_msg)
{
    cv_bridge::CvImagePtr bridge_ptr = cv_bridge::toCvCopy(img_msg, sensor_msgs::image_encodings::MONO8);
    MDetector.detect(bridge_ptr->image, Markers);
    TheBoardDetector.detect(Markers, TheBoardConfig, TheBoardDetected, CamParam, MarkerSize);

    vector<int> pts_id; vector<cv::Point3f> pts_3; vector<cv::Point2f> pts_2;
    for (unsigned int i = 0; i < Markers.size(); i++)
    {
        int idx = TheBoardConfig.getIndexOfMarkerId(Markers[i].id);
        char str[64]; sprintf(str, "%d", idx);
        cv::putText(bridge_ptr->image, str, Markers[i].getCenter(),
            cv::FONT_HERSHEY_COMPLEX, 0.5, cv::Scalar(255));
        for (unsigned int j = 0; j < 4; j++) {
            sprintf(str, "%d", j);
            cv::putText(bridge_ptr->image, str, Markers[i][j],
                cv::FONT_HERSHEY_COMPLEX, 0.5, cv::Scalar(0, 255, 0));
        }
        for (unsigned int j = 0; j < 4; j++) {
            pts_id.push_back(Markers[i].id * 4 + j);
            pts_3.push_back(getPositionFromIndex(idx, j));
            pts_2.push_back(Markers[i][j]);
        }
    }

    if (pts_id.size() > 5) process(pts_id, pts_3, pts_2, img_msg->header.stamp);
    cv::imshow("in", bridge_ptr->image); cv::waitKey(1);
}

// ======================= main =======================
int main(int argc, char** argv)
{
    ros::init(argc, argv, "tag_detector");
    ros::NodeHandle n("~");

    sub_img = n.subscribe("image_raw", 100, img_callback);
    pub_path_ref = n.advertise<nav_msgs::Path>("path_ref", 10);
    pub_path = n.advertise<nav_msgs::Path>("path_yourwork", 10);
    pub_odom_ref = n.advertise<nav_msgs::Odometry>("odom_ref", 10);
    pub_odom = n.advertise<nav_msgs::Odometry>("odom_yourwork", 10);
    pub_arrow_ref = n.advertise<visualization_msgs::Marker>("axis_ref", 10);
    pub_arrow = n.advertise<visualization_msgs::Marker>("axis_yourwork", 10);

    // ��ȡ����
    std::string cam_cal, board_config;
    n.getParam("cam_cal_file", cam_cal);
    n.getParam("board_config_file", board_config);
    CamParam.readFromXMLFile(cam_cal);
    TheBoardConfig.readFromFile(board_config);

    // ����ڲ�
    cv::FileStorage fs(cam_cal, cv::FileStorage::READ);
    fs["camera_matrix"] >> K; fs["distortion_coefficients"] >> D;

    cv::namedWindow("in", 1);
    ros::spin();
    return 0;