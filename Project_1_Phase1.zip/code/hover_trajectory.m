function s_des = hover_trajectory(t, true_s)
% 原点悬停、水平姿态

s_des = zeros(13,1);
s_des(7:10)  = [1;0;0;0];   % 水平姿态四元数(BRW)
s_des(11:13) = [0;0;0];
end
