function [F, M] = controller(t, s, s_des)
global params
m = params.mass; g = params.grav; I = params.I;

% 当前与期望
p = s(1:3); v = s(4:6); q = s(7:10); omega = s(11:13);
p_d = s_des(1:3); v_d = s_des(4:6);
q_d = s_des(7:10); omega_d = s_des(11:13);

% ===== 位置外环 -> a_des =====
Kp = diag([6.0, 6.0, 9.0]);     % 起步值（xy 稍小，z 稍大）
Kd = diag([4.0, 4.0, 6.0]);
e_p = p_d - p;
e_v = v_d - v;
a_des = Kp*e_p + Kd*e_v + [0;0;g];     % 含重力补偿

% ===== 推力 F（沿机体 z 轴）=====
R_wb = QuatToRot(q)';                   % WRB: Body->World
b3    = R_wb*[0;0;1];
F     = m * dot(a_des, b3);
F     = min(max(F, params.minF), params.maxF);

% ===== 核心修复：由 a_des + ψ_des 构造 R_des（而不是直接用轨迹 q_des）=====
% 从轨迹四元数提取期望偏航（ZYX yaw）
R_wb_des_traj = QuatToRot(q_d)';        % WRB
psi_des = atan2(R_wb_des_traj(2,1), R_wb_des_traj(1,1));

% 设定参考轴：b3_des 指向 a_des 方向；b1_c 由期望偏航给定
if norm(a_des) < 1e-6, a_des = [0;0;g]; end
b3_des = a_des / norm(a_des);
b1_c   = [cos(psi_des); sin(psi_des); 0];
b2_des = cross(b3_des, b1_c);  b2_des = b2_des / max(1e-6, norm(b2_des));
b1_des = cross(b2_des, b3_des);
R_des  = [b1_des, b2_des, b3_des];      % WRB

% ===== 姿态 PD（SO(3) 几何误差） -> 力矩 M =====
e_R  = 0.5 * vee( R_des' * R_wb - R_wb' * R_des );
e_Om = omega - R_wb' * R_des * [0;0;0]; % 期望角速度置 0

KR = diag([3.5, 3.5, 2.5]);             % 姿态比例
KO = diag([0.20, 0.20, 0.18]);          % 角速度阻尼
M  = - KR*e_R - KO*e_Om + cross(omega, I*omega);

% =====（可选）RMS 统计====
global rms_xposition rms_xvelocity rms_yposition rms_yvelocity rms_zposition rms_zvelocity
rms_xposition = [rms_xposition, (p_d(1)-p(1))];
rms_xvelocity = [rms_xvelocity, (v_d(1)-v(1))];
rms_yposition = [rms_yposition, (p_d(2)-p(2))];
rms_yvelocity = [rms_yvelocity, (v_d(2)-v(2))];
rms_zposition = [rms_zposition, (p_d(3)-p(3))];
rms_zvelocity = [rms_zvelocity, (v_d(3)-v(3))];
end

function v = vee(S), v = [S(3,2); S(1,3); S(2,1)]; end
